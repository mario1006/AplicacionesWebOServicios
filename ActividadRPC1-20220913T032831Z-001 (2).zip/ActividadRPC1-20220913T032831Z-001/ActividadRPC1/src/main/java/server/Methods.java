package server;

import java.util.Arrays;

public class Methods {

    private int[] arrayIn = new int[5];

    public int[] getArrayIn() {
        return arrayIn;
    }

    public int[] setArrayIn() {
        this.arrayIn = arrayIn;
        return arrayIn;
    }

    public int[] ordenarArray(){

        Arrays.sort(arrayIn);

        for (int i=0;i<arrayIn.length;i++){
            System.out.println(arrayIn[i]);
        }
        return arrayIn;
    }


}
