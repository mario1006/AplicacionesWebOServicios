package client;
import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import server.Methods;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Scanner;

public class RPCClient {
    public static void main(String[] args) throws MalformedURLException, XmlRpcException {
        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL("http://localhost:1200"));
        XmlRpcClient client = new XmlRpcClient();
        client.setConfig(config);
        /*Object[] data = {3.6,10D};
        Double response = (Double) client.execute("Methods.addition",data);
        System.out.println("Result ->"+response);
*/
        Scanner leer = new Scanner(System.in);
        Methods met = new Methods();

        int[] arrayIn = new int[5];

/*

        for (int i=0;i<arrayIn.length;i++){
            System.out.println(arrayIn[i]+" Ingresa un numero");
            arrayIn[i] = leer.nextInt();
        }

        Arrays.sort(arrayIn);

        for (int i=0;i<arrayIn.length;i++){
            System.out.println(" "+arrayIn[i]);
        }
*/
        for (int i=0;i<arrayIn.length;i++){
            System.out.println("Ingresa un numero");
            arrayIn[i] = leer.nextInt();
            arrayIn = met.setArrayIn();
        }

        System.out.println(met.ordenarArray());



    }

}
